
from flask import Flask, request, jsonify, send_from_directory
from datetime import datetime
from ecourt_client import fetch_case_details_api, fetch_cause_list_api

app = Flask(__name__, static_folder='data')

@app.get('/')
def index():
    return """<h2>eCourts Scraper API</h2>
    <p>Endpoints:</p>
    <ul>
      <li>/case?cnr=&lt;cnr&gt;&date=&lt;YYYY-MM-DD&gt;</li>
      <li>/case?type=&lt;type&gt;&number=&lt;n&gt;&year=&lt;y&gt;&date=&lt;YYYY-MM-DD&gt;</li>
      <li>/causelist?date=&lt;YYYY-MM-DD&gt;</li>
    </ul>
    """

@app.get('/case')
def case_endpoint():
    cnr = request.args.get('cnr')
    case_type = request.args.get('type')
    number = request.args.get('number')
    year = request.args.get('year')
    date = request.args.get('date')
    if date:
        try:
            date = datetime.strptime(date, '%Y-%m-%d').date()
        except:
            return jsonify({'error': 'date must be YYYY-MM-DD'}), 400
    else:
        date = datetime.now().date()

    result = fetch_case_details_api(cnr=cnr, case_type=case_type, number=number, year=year, date=date)
    return jsonify(result)

@app.get('/causelist')
def cause_endpoint():
    date = request.args.get('date')
    if date:
        try:
            date = datetime.strptime(date, '%Y-%m-%d').date()
        except:
            return jsonify({'error': 'date must be YYYY-MM-DD'}), 400
    else:
        date = datetime.now().date()

    result = fetch_cause_list_api(date)
    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True)
