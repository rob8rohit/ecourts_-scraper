# eCourts Cause List Downloader (Internship Task)
**Target:** services.ecourts.gov.in (main eCourts portal) — includes human-in-the-loop captcha handling.

## What this project does
- Simple Flask UI where user inputs State, District, Court Complex (optional) and Date.
- Backend uses Selenium to navigate to the eCourts cause list page.
- If a captcha appears, the scraper saves the captcha image and the UI shows it to the user.
- User types the captcha into the UI; backend picks it up and continues scraping.
- Downloads any found PDF cause-lists and packages them into `cause_lists.zip` for download.

## Files
- `app.py` — Flask web app and job management.
- `scraper.py` — Selenium-based scraper with captcha-handling logic.
- `templates/index.html` — Simple UI.
- `requirements.txt` — Python dependencies.

## How to run (Linux / Windows WSL)
1. Install python 3.10+ and Chrome browser.
2. Create virtualenv and install requirements:
   ```bash
   python -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```
3. Run the Flask app:
   ```bash
   python app.py
   ```
4. Open `http://localhost:5000` in your browser.
5. Enter date and other optional fields. Click Start.
6. If a captcha appears, the UI will show it — type it and submit.
7. When job completes, click the Download ZIP link.

## Notes & Caveats
- The eCourts site frequently changes markup; the scraper uses best-effort selectors. Inspect and adapt selectors if scraping fails.
- Respect site terms, rate limits and do not bulk-download excessively.
- For district-court sites (e.g., `newdelhi.dcourts.gov.in`) a simpler scraper may skip the captcha step. Consider using district sites for easier automation.
- This project is provided as a demo for the internship assignment. Use responsibly.
