import os, time, zipfile, shutil
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from datetime import datetime
import tempfile
import requests

class EcourtsScraper:
    """Scraper for services.ecourts.gov.in cause list with human captcha step.
    This implementation uses Selenium to load the page, captures the captcha image
    and saves it to the job outdir as captcha.png. The Flask app will expose that
    image to the user. The scraper then waits for a file 'captcha_solution.txt'
    to appear in the outdir with the typed captcha value and continues.
    Note: selectors on the eCourts site may change; adjust find_element calls accordingly.
    """
    def __init__(self, outdir):
        self.outdir = outdir
        os.makedirs(self.outdir, exist_ok=True)
        self.download_dir = self.outdir  # keep downloads in the same folder

    def _init_driver(self):
        options = Options()
        prefs = {
            "download.default_directory": os.path.abspath(self.download_dir),
            "download.prompt_for_download": False,
        }
        options.add_experimental_option('prefs', prefs)
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        driver = webdriver.Chrome(ChromeDriverManager().install(), options=options)
        driver.set_page_load_timeout(60)
        return driver

    def run(self, state, district, court_complex, date, job_id=None):
        driver = self._init_driver()
        try:
            url = 'https://services.ecourts.gov.in/ecourtindia_v6/?p=cause_list/'
            driver.get(url)
            time.sleep(2)

            try:
                state_sel = driver.find_element(By.ID, 'state_name')
                state_sel.send_keys(state or '')
            except Exception:
                pass

            try:
                dist_sel = driver.find_element(By.ID, 'district_code')
                dist_sel.send_keys(district or '')
            except Exception:
                pass

            time.sleep(1)

            try:
                date_input = driver.find_element(By.ID, 'cause_list_date')
                date_input.clear()
                date_input.send_keys(date)
            except Exception:
                pass

            time.sleep(1)

            try:
                search_btn = driver.find_element(By.ID, 'searchbutton')
                search_btn.click()
            except Exception:
                try:
                    buttons = driver.find_elements(By.TAG_NAME, 'button')
                    for b in buttons:
                        if 'Search' in b.text or 'Display' in b.text or 'Get' in b.text:
                            b.click()
                            break
                except:
                    pass

            time.sleep(2)

            captcha_img = None
            try:
                captcha_img = driver.find_element(By.XPATH, "//img[contains(@src,'captcha') or contains(@id,'captcha') or contains(@alt,'captcha')]")
            except Exception:
                try:
                    captcha_img = driver.find_element(By.CSS_SELECTOR, 'img')
                except:
                    captcha_img = None

            if captcha_img:
                src = captcha_img.get_attribute('src')
                captcha_path = os.path.join(self.outdir, 'captcha.png')
                if src.startswith('data:'):
                    import base64, re
                    m = re.match(r'data:(image/\w+);base64,(.*)', src)
                    if m:
                        with open(captcha_path, 'wb') as f:
                            f.write(base64.b64decode(m.group(2)))
                else:
                    try:
                        res = requests.get(src, timeout=15)
                        with open(captcha_path, 'wb') as f:
                            f.write(res.content)
                    except Exception:
                        captcha_img.screenshot(captcha_path)

                static_job_dir = os.path.join('static','ecourts_jobs', job_id or 'job')
                os.makedirs(static_job_dir, exist_ok=True)
                shutil.copy(captcha_path, os.path.join(static_job_dir, 'captcha.png'))

                solution_file = os.path.join(self.outdir, 'captcha_solution.txt')
                waited = 0
                while not os.path.exists(solution_file) and waited < 300:
                    time.sleep(1)
                    waited += 1
                if not os.path.exists(solution_file):
                    raise Exception('Captcha not solved within 300s')

                with open(solution_file, 'r') as f:
                    captcha_value = f.read().strip()

                try:
                    cap_input = driver.find_element(By.NAME, 'captcha')
                    cap_input.clear()
                    cap_input.send_keys(captcha_value)
                    try:
                        submit_btn = driver.find_element(By.XPATH, "//button[contains(text(),'Submit') or contains(text(),'Search')]")
                        submit_btn.click()
                    except:
                        pass
                except Exception:
                    driver.execute_script("document.querySelector('input[name="captcha"]').value = arguments[0];", captcha_value)

                time.sleep(2)

            pdf_links = set()
            anchors = driver.find_elements(By.TAG_NAME, 'a')
            for a in anchors:
                href = a.get_attribute('href') or ''
                if href.endswith('.pdf') or 'cause_list' in href or 'causelist' in href or 'cause-list' in href:
                    pdf_links.add(href)

            if not pdf_links:
                rows = driver.find_elements(By.XPATH, "//table//tr")
                for r in rows:
                    try:
                        a = r.find_element(By.TAG_NAME, 'a')
                        href = a.get_attribute('href') or ''
                        if href:
                            pdf_links.add(href)
                    except:
                        continue

            saved = []
            for i, link in enumerate(sorted(pdf_links)):
                try:
                    if link.startswith('http'):
                        r = requests.get(link, timeout=20)
                        fname = os.path.join(self.download_dir, f'cause_{i+1}.pdf')
                        with open(fname, 'wb') as f:
                            f.write(r.content)
                        saved.append(fname)
                except Exception:
                    continue

            zipname = os.path.join(self.outdir, 'cause_lists.zip')
            with zipfile.ZipFile(zipname, 'w') as z:
                for s in saved:
                    z.write(s, arcname=os.path.basename(s))

            return {'zip': zipname, 'count': len(saved)}
        finally:
            try:
                driver.quit()
            except:
                pass
