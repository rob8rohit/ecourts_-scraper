from flask import Flask, render_template, request, jsonify, send_file, url_for
import os, uuid, tempfile
from scraper import EcourtsScraper
import threading, time

app = Flask(__name__)
JOBS = {}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/start', methods=['POST'])
def start():
    payload = request.json
    date = payload.get('date')
    state = payload.get('state')
    district = payload.get('district')
    court = payload.get('court')
    job_id = str(uuid.uuid4())[:8]
    outdir = os.path.join(tempfile.gettempdir(), 'ecourts_jobs', job_id)
    os.makedirs(outdir, exist_ok=True)

    scraper = EcourtsScraper(outdir=outdir)
    JOBS[job_id] = {'status':'running', 'outdir': outdir}

    def run_job():
        try:
            result = scraper.run(state=state, district=district, court_complex=court, date=date, job_id=job_id)
            JOBS[job_id]['status'] = 'done'
            JOBS[job_id]['result'] = result
        except Exception as e:
            JOBS[job_id]['status'] = 'error'
            JOBS[job_id]['error'] = str(e)

    thread = threading.Thread(target=run_job, daemon=True)
    thread.start()

    return jsonify({'job_id': job_id, 'status':'started'})

@app.route('/status/<job_id>')
def status(job_id):
    job = JOBS.get(job_id)
    if not job:
        return jsonify({'status':'notfound'}), 404
    return jsonify(job)

@app.route('/captcha/<job_id>')
def captcha(job_id):
    """Return captcha image URL (if produced)"""
    job = JOBS.get(job_id)
    if not job:
        return jsonify({'status':'notfound'}), 404
    outdir = job['outdir']
    captcha_path = os.path.join(outdir, 'captcha.png')
    if os.path.exists(captcha_path):
        return jsonify({'status':'captcha', 'captcha_url': url_for('static', filename=f'ecourts_jobs/{job_id}/captcha.png')})
    return jsonify({'status':'nocaptcha'})

@app.route('/submit_captcha/<job_id>', methods=['POST'])
def submit_captcha(job_id):
    data = request.json
    value = data.get('captcha')
    job = JOBS.get(job_id)
    if not job:
        return jsonify({'status':'notfound'}), 404
    outdir = job['outdir']
    capfile = os.path.join(outdir, 'captcha_solution.txt')
    with open(capfile, 'w') as f:
        f.write(value or '')
    return jsonify({'status':'ok'})

@app.route('/download/<job_id>')
def download(job_id):
    job = JOBS.get(job_id)
    if not job:
        return "Job not found", 404
    outdir = job['outdir']
    zipfile = os.path.join(outdir, 'cause_lists.zip')
    if not os.path.exists(zipfile):
        return "Not ready", 404
    return send_file(zipfile, as_attachment=True, download_name='cause_lists.zip')

if __name__ == '__main__':
    import pathlib, shutil
    static_base = os.path.join('static','ecourts_jobs')
    pathlib.Path(static_base).mkdir(parents=True, exist_ok=True)
    app.run(debug=True, port=5000)
