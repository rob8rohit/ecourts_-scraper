
from bs4 import BeautifulSoup
import re
from datetime import date as dt

def parse_case_page_for_listings(soup: BeautifulSoup, target_date):
    """Given a BeautifulSoup of a case search result page, try to extract
    listing rows that match target_date (a date object). Returns list of dicts."""
    listings = []
    # heuristic: find tables and rows containing dates and court names
    tables = soup.find_all('table')
    for table in tables:
        headers = [h.get_text(strip=True).lower() for h in table.find_all('th')]
        rows = table.find_all('tr')
        for r in rows:
            cols = [c.get_text(strip=True) for c in r.find_all(['td','th'])]
            if not cols or len(cols) < 2:
                continue
            row_text = ' '.join(cols).lower()
            # find date-like substrings yyyy-mm-dd or dd/mm/yyyy or dd-mm-yyyy
            m = re.search(r'(\d{4}-\d{2}-\d{2})', row_text) or re.search(r'(\d{1,2}[/-]\d{1,2}[/-]\d{4})', row_text)
            if not m:
                continue
            found = m.group(1)
            try:
                # normalize dd/mm/yyyy to yyyy-mm-dd for comparison
                if '/' in found or '-' in found and len(found.split('-')[0])==4:
                    from datetime import datetime
                    if '/' in found:
                        d = datetime.strptime(found, '%d/%m/%Y').date()
                    else:
                        # could be yyyy-mm-dd or dd-mm-yyyy; try both
                        parts = found.split('-')
                        if len(parts[0])==4:
                            d = datetime.strptime(found, '%Y-%m-%d').date()
                        else:
                            d = datetime.strptime(found, '%d-%m-%Y').date()
                else:
                    continue
            except Exception:
                continue
            if d == target_date:
                # attempt to extract serial and court name heuristically
                serial = cols[0] if cols else ''
                court = cols[1] if len(cols) > 1 else ''
                # find pdf links in the row
                pdf = None
                link = r.find('a', href=True)
                if link and link['href'].lower().endswith('.pdf'):
                    pdf = link['href']
                listings.append({'serial_number': serial, 'date': str(d), 'court_name': court, 'pdf_url': pdf})
    return listings

def parse_causelist_index(soup: BeautifulSoup, target_date):
    entries = []
    # find anchors with 'cause' or 'cause list' in text
    for a in soup.find_all('a', href=True):
        t = a.get_text(strip=True).lower()
        if 'cause' in t or 'cause list' in t or 'cause-list' in a['href']:
            url = a['href']
            text = a.get_text(strip=True)
            entries.append({'text': text, 'url': url})
    # deduplicate
    seen = set()
    out = []
    for e in entries:
        if e['url'] in seen:
            continue
        seen.add(e['url'])
        out.append(e)
    return out
