
# eCourts Scraper - CLI + Flask API

**What**: A Python project to check eCourts case listings (today / tomorrow), optionally download PDFs and full cause lists.
**Includes**: CLI (`main.py`) and a simple Flask API (`app.py`).

## Usage (CLI)
```bash
# Check by CNR for today
python main.py --cnr "TNCH010000012023" --today

# Check by case type/number/year for tomorrow and download PDF
python main.py --type "CRL" --number 102 --year 2023 --tomorrow --pdf

# Download full cause list for today
python main.py --causelist --today
```

## Usage (Flask)
```bash
pip install -r requirements.txt
python app.py
# Open http://127.0.0.1:5000/ and use endpoints:
# /case?cnr=...&date=YYYY-MM-DD
# /causelist?date=YYYY-MM-DD
```

## Files
- main.py          CLI entrypoint
- app.py           Flask API wrapper
- ecourt_client.py core fetching/parsing logic (scraper)
- parsers.py       HTML parsing helpers
- utils.py         helper utilities and file IO
- requirements.txt python dependencies
- data/            stores JSON results and downloaded PDFs (ignored by git)
