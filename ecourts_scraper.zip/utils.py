
import os, json

def ensure_data_dir():
    os.makedirs('data', exist_ok=True)

def save_json(obj, path):
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)

def save_binary(data, path):
    with open(path, 'wb') as f:
        f.write(data)
