
import os, json, re, requests
from bs4 import BeautifulSoup
from utils import ensure_data_dir, save_json, save_binary
from parsers import parse_case_page_for_listings, parse_causelist_index

BASE = 'https://services.ecourts.gov.in/ecourtindia_v6/'

# NOTE: The eCourts site changes frequently. The functions below attempt to use
# form endpoints and parse HTML reasonably; you may need to adjust selectors
# if the site structure differs at runtime.

def fetch_case_details_cli(args, date):
    cnr = args.cnr
    case_type = getattr(args, 'case_type', None)
    number = args.number
    year = args.year
    result = fetch_case_details(cnr=cnr, case_type=case_type, number=number, year=year, date=date, download_pdf=args.pdf)
    print(json.dumps(result, indent=2))
    ensure_data_dir()
    fname = f"data/case_result_{date}.json"
    save_json(result, fname)
    print(f"Saved result -> {fname}")

def fetch_cause_list_cli(date):
    result = fetch_cause_list(date)
    print(json.dumps({'date': str(date), 'entries': len(result['entries'])}, indent=2))
    ensure_data_dir()
    fname = f"data/cause_list_{date}.json"
    save_json(result, fname)
    print(f"Saved cause list -> {fname}")

# API wrapper functions return dicts (no file IO)
def fetch_case_details_api(cnr=None, case_type=None, number=None, year=None, date=None):
    return fetch_case_details(cnr=cnr, case_type=case_type, number=number, year=year, date=date, download_pdf=False)

def fetch_cause_list_api(date):
    return fetch_cause_list(date)

def fetch_case_details(cnr=None, case_type=None, number=None, year=None, date=None, download_pdf=False):
    # Try CNR first if provided
    session = requests.Session()
    headers = {'User-Agent': 'ecourts-scraper/1.0'}
    session.headers.update(headers)

    if cnr:
        # There's an advanced search endpoint; attempt to use it.
        # This is a best-effort implementation and may need tweaks.
        payload = {'cnr': cnr}
        # use search URL (may require real endpoint discovery).
        url = BASE + 'search?'
        res = session.post(url, data=payload, timeout=20)
    else:
        payload = {'case_type': case_type or '', 'case_no': number or '', 'case_year': year or ''}
        url = BASE + 'search?'
        res = session.post(url, data=payload, timeout=20)

    # Parse response conservatively
    listings = []
    try:
        soup = BeautifulSoup(res.text, 'html.parser')
        listings = parse_case_page_for_listings(soup, date)
    except Exception as e:
        return {'error': 'parsing error', 'details': str(e)}

    result = {
        'query': {'cnr': cnr, 'case_type': case_type, 'number': number, 'year': year},
        'date_checked': str(date),
        'listed': len(listings) > 0,
        'listings': listings
    }

    # optionally download PDFs if listing contains pdf links and user asked
    if download_pdf and listings:
        ensure_data_dir()
        for i, item in enumerate(listings):
            pdf_url = item.get('pdf_url')
            if pdf_url:
                try:
                    resp = session.get(pdf_url, timeout=30)
                    name = f"data/pdf_{str(date)}_{i}.pdf"
                    save_binary(resp.content, name)
                    item['pdf_local'] = name
                except Exception as e:
                    item['pdf_error'] = str(e)

    return result

def fetch_cause_list(date):
    session = requests.Session()
    session.headers.update({'User-Agent': 'ecourts-scraper/1.0'})
    # Best-effort: open main page and look for cause list links
    res = session.get(BASE, timeout=20)
    soup = BeautifulSoup(res.text, 'html.parser')
    entries = parse_causelist_index(soup, date)
    # Try to download PDFs for entries that look like cause lists
    ensure_data_dir()
    results = {'date': str(date), 'entries': entries}
    return results
