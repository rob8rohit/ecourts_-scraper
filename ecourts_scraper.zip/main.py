
#!/usr/bin/env python3
import argparse
from datetime import datetime, timedelta
from ecourt_client import fetch_case_details_cli, fetch_cause_list_cli

def parse_args():
    p = argparse.ArgumentParser(description="eCourts listing checker (CLI)")
    group = p.add_mutually_exclusive_group()
    p.add_argument("--cnr", help="CNR number (preferred)")
    p.add_argument("--type", dest="case_type", help="Case Type (if no CNR)")
    p.add_argument("--number", help="Case Number (if no CNR)")
    p.add_argument("--year", help="Case Year (if no CNR)")
    p.add_argument("--today", action="store_true", help="Check for today (default if no date flag)")
    p.add_argument("--tomorrow", action="store_true", help="Check for tomorrow")
    p.add_argument("--pdf", action="store_true", help="Download case PDF if available")
    p.add_argument("--causelist", action="store_true", help="Download entire cause list for the date")
    return p.parse_args()

def main():
    args = parse_args()
    if args.today:
        date = datetime.now().date()
    elif args.tomorrow:
        date = datetime.now().date() + timedelta(days=1)
    else:
        date = datetime.now().date()

    if args.causelist:
        fetch_cause_list_cli(date)
    else:
        fetch_case_details_cli(args, date)

if __name__ == '__main__':
    main()
